# Reporting OpenSSH Security Issues

To report security issues in OpenSSH, please refer to our website
[OpenSSH Security](https://www.openssh.com/security.html).

